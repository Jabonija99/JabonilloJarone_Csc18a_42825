public class FractionDriver {

    public static void main(String[] args) {
        Fraction a = new Fraction();        
        Fraction b = new Fraction(4,6);
        
        System.out.println(a.toString());
        System.out.println(b.toString());
    }
    
}
